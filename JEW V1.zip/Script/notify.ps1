# Set your Webhook URL here
$webhookUrl = "https://discord.com/api/webhooks/1508286656573083719/GdHbeeuWYaw2vo9CGL-ptMmGgRfV2GBAFgsWBWMY7THjhKhtA122dNsKqKs9th9QtmCH"

# Define the message content
$payload = @{
    content = "@everyone"
} | ConvertTo-Json

# Send the request
try {
    Invoke-RestMethod -Uri $webhookUrl -Method Post -Body $payload -ContentType "application/json"
    Write-Host "Notification sent successfully!" -ForegroundColor Green
}
catch {
    Write-Host "Failed to send notification: $_" -ForegroundColor Red
}