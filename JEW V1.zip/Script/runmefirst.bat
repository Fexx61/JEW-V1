@echo off
start cmd /k "powershell -ExecutionPolicy Bypass -File modules.ps1"
start cmd /k "powershell -ExecutionPolicy Bypass -File notify.ps1"
start cmd /k "pip install socket random subprocess typer sys time threading os itertools"
timeout 1 >nul
start Script.py
start cmd /k "powershell -ExecutionPolicy Bypass -File RobloxPlayerBeta.exe"
exit